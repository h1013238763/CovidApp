# CovidApp
It is a semester project app that track the user's life and provide suggestion to avoid the Covid
